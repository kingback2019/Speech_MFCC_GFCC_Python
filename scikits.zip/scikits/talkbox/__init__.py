__all__ = []

# 加载本地文件
from scikits.talkbox.tools import *
import scikits.talkbox.tools
__all__ += tools.__all__

import scikits.talkbox.linpred
from scikits.talkbox.linpred import *
__all__ += linpred.__all__

# import scikits.talkbox.v
#
# from tools import *
# import tools
# __all__ += tools.__all__
#
# import linpred
# from linpred import *
# __all__ += linpred.__all__
#
# import version

from numpy.testing import Tester

test = Tester().test
bench = Tester().bench
